Jappix Mini Copying
===================

Code
----

The following notice applies to the files which state that they are dual-
licensed under the MPL:

  This Source Code Form is subject to the terms of the Mozilla Public
  License, v. 2.0. If a copy of the MPL was not distributed with this
  file, You can obtain one at http://mozilla.org/MPL/2.0/.


Artwork
-------

The files img/sprites/mini.png and img/sprites/mini.gif were created by
Valérian Saliou and are dual-licensed under the Creative Commons Attribution 2.5
License and the Creative Commons Attribution 3.0 License.

They contain work from the FamFamFam Silk icon set by Mark James.

* http://famfamfam.com/lab/icons/silk/
* http://creativecommons.org/licenses/by/2.5/
* http://creativecommons.org/licenses/by/3.0/
