Jappix Test
===========

Test tools used by our CI (Continuous Integration) system to run tests on our code once a commit is made.

If you need to run tests manually, run (on base directory):

> npm test
