Jappix Authors
==============

Here are the Jappix contributors, who coded or translated the application:


Founders
--------

* Valérian Saliou
* Julien Barrier


Developers
----------

* am0ur3ux
* Camaran
* Cyril "Kyriog" Glapa
* hunterjm
* LinkMauve
* Maranda
* Mathieui
* Olivier
* sim6


Translators
-----------

* allan
* Arsimael
* Belzeneph
* camaran
* Catdarko
* Cerritus
* chunzu
* ebraminio
* Eraser
* Finkregh
* GenghisKhan
* hamano
* JanCBorchardt
* jarda
* joeka
* kahpa
* kr2ysiek
* krohn
* Lenwe
* LinkMauve
* Liverbool
* lwj
* m1st
* Maime
* Maranda
* mbajur
* mentalo
* mkwm
* Natureshadow
* Och.Oyuka
* Otourly
* piotr.moskal
* pocamon
* quimi
* sahwar
* Valérian Saliou
* vitalyster
* zAchAry
* Zash
